﻿using Microsoft.Azure.ServiceBus;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PR.Notifications.Services
{
    public class ServiceBusConsumer
    {
        private readonly QueueClient queueClient;
        public ServiceBusConsumer(IConfiguration configuration)
        {
            queueClient = new QueueClient(configuration.GetConnectionString("ServiceBusConnectionString"),"messages");
        }

        public void Register()
        {
            var options = new MessageHandlerOptions((e) => Task.CompletedTask)
            {
                AutoComplete = false
                };
            queueClient.RegisterMessageHandler(ProcessMessage, options);
        }

        private async Task ProcessMessage(Message message, CancellationToken token)
        {
            var payload = JsonConvert.DeserializeObject<MessagePayLoad>(Encoding.UTF8.GetString(message.Body));

            if(payload.EventName == "NewPacientRegistered")
            {
                EmailSender sender = new EmailSender();

                sender.SendNewPacientEmail(payload.PacientEmail);
            }

            await queueClient.CompleteAsync(message.SystemProperties.LockToken);
        }
    }
    public class MessagePayLoad
    {
        public string EventName { get; set; }

        public string PacientEmail { get; set; }
    }
}
