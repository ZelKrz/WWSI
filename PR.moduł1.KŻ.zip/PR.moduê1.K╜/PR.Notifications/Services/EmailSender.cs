﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

namespace PR.Notifications.Services
{
    public class EmailSender
    {
        public void SendNewPacientEmail(string email)
        {
            var smtpClient = new SmtpClient("smtp.gmail.com")
            {
                Port = 587,
                Credentials = new NetworkCredential("bbilytskyi@gmail.com", "Orangutan32"),
                EnableSsl = true,
            };

            smtpClient.Send("bbilytskyi@gmail.com", email, "Covid 19", "Wiadomość o kwarantannie - zostań w domu przez 10 dni");
        }
    }
}
