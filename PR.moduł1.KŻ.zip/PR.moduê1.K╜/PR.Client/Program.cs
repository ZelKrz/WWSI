﻿using System;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace PR.Client
{
    class Program
    {
        static async Task Main(string[] args)
        {
            HttpClient client = new HttpClient();

            Pacient p = new Pacient()
            {
                Name = "Krzysiek",
                Surname = "Iron",
                Age = 33,
                TestDate = DateTime.Now
            };

            string pacientJson=JsonSerializer.Serialize(p);

            await client.PostAsync("https://localhost:5001/api/pacients", new StringContent(pacientJson, Encoding.UTF8, "application/json"));
        }
    }
    public class Pacient
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public int Age { get; set; }
        public DateTime TestDate { get; set; }
    }
}
