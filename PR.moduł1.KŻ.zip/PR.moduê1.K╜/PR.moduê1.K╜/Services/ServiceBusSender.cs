﻿using Microsoft.Azure.ServiceBus;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR.moduł1.KŻ.Services
{
    public class ServiceBusSender
    {
        private readonly QueueClient queueClient;
        public ServiceBusSender(IConfiguration configuration)
        {
            queueClient = new QueueClient(configuration.GetConnectionString("ServiceBusConnectionString"), "messages");
        }
        public async Task SendMessage(MessagePayLoad payLoad)
        {
            string data = JsonConvert.SerializeObject(payLoad);

            Message message = new Message(Encoding.UTF8.GetBytes(data));

            await queueClient.SendAsync(message);
        }
    }
    public class MessagePayLoad
    {
        public string EventName { get; set; }

        public string PacientEmail { get; set; }
    }
}
