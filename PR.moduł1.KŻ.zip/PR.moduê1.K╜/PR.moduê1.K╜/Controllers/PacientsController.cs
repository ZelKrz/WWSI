﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PR.moduł1.KŻ.Model;
using PR.moduł1.KŻ.Services;

namespace PR.moduł1.KŻ.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PacientsController : ControllerBase
    {
        private PacientsDataContext context;
        private readonly ServiceBusSender sender;

        public PacientsController(PacientsDataContext context, ServiceBusSender sender)
        {
            this.context = context;
            this.sender = sender;
        }
       
        [HttpGet]
        public IActionResult GetData()
        {
            return Ok(this.context.Pacients.ToList());
        }
        [HttpPost]
        public async Task <IActionResult> AddPacient(Pacient p)
        {
            this.context.Pacients.Add(p);
            this.context.SaveChanges();

            //HttpClient client = new HttpClient();


            //string emailJson = JsonSerializer.Serialize(new EmailMessageRequest()
            //{
            //    EmailAddress="kzelazny31@gmail.com",
            //    Subject="Zarejestrowano pacjenta",
            //    Body="Informacja o kwarantannie"
            //}
            //    );

            //await client.PostAsync("https://localhost:5002/api/email", new StringContent(emailJson, Encoding.UTF8, "application/json"));

            await sender.SendMessage(new MessagePayLoad() {EventName = "NewPacientRegistered", PacientEmail = "kzelazny31@gmail.com"});

            return Created("/api/pacients/", p);
        }
    }

    //public class EmailMessageRequest
    //{
    //    public string EmailAddress { get; set; }
    //    public string Subject { get; set; }
    //    public string Body { get; set; }
    //}
}
