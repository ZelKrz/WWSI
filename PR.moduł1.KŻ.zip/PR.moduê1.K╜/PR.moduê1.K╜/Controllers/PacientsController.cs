﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PR.moduł1.KŻ.Model;
using Microsoft.EntityFrameworkCore;

namespace PR.moduł1.KŻ.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PacientsController : ControllerBase
    {
        private PacientsDataContext context;

        public PacientsController(PacientsDataContext context)
        {
            this.context = context;
        }
       
        [HttpGet]
        public IActionResult GetData()
        {
            return Ok(this.context.Pacients.ToList());
        }
        [HttpPost]
        public IActionResult AddPacient(Pacient p)
        {
            this.context.Pacients.Add(p);
            this.context.SaveChanges();
            return Created("/api/pacients/", p);
        }
    }
}
