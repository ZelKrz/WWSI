﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PR.moduł1.KŻ.Model
{
    public class PacientsDataContext: DbContext
    {
        public PacientsDataContext(DbContextOptions options): base(options)
        {

        }
        public DbSet<Pacient> Pacients { get; set; }
    }
}
